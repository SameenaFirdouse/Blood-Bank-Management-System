<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: black;
   text-align: center;
   padding: 5px 0px 5px 0px;
}
</style>
</head>
<body>

<div class="footer">
  <p>© Copyright 2024<span id="demo"></span> <span class="brand">Blood Bank. </span> All Rights Reserved.
</footer></p>
</div>

</body>
</html> 